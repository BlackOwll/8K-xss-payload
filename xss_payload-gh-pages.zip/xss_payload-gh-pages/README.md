# 8000+ xss_payloads

Curated by : Abhishek Meena (aacle_)

Credit : All the Bug Bounty Hunters

<!--## 1.xss Payload 

Check Out Payload List No.1
[LINK](https://aacle.github.io/xss_payload/xss01_Payload)

## 2.xss Payload 

Check Out Payload List No.2
[LINK](https://aacle.github.io/xss_payload/xss02_Payload)

## 3.xss Payload 

Check Out Payload List No.3
[LINK](https://aacle.github.io/xss_payload/xss03_Payload)

## 4.xss Payload 

Check Out Payload List No.4
[LINK](https://aacle.github.io/xss_payload/xss04_Payload)

## 5.xss Payload 

Check Out Payload List No.5
[LINK](https://aacle.github.io/xss_payload/xss05_Payload)

## 6. xss project

Check Out Payload List No.6
[LINK](https://aacle.github.io/xss_payload/xssProjects)


-->
